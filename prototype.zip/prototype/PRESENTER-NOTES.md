# ARISEVERSE — Website + Learning Portal Prototype

Clickable HTML prototype built from the client documents in this folder. No build step and no backend.
Hosted copy (private until shared from its Share menu): https://claude.ai/artifact/KxNnsFnYTYynQwBKjHN8n3
Open `index.html` in Chrome or Safari. The website links into `portal.html`, the learning portal.
Everything is sample data, and nothing typed into a form is sent anywhere.

## Suggested demo path (about 10 minutes)

1. **Home** (`index.html`). Hero line "From Learning to Earning. From Bunkbed to Villa." Then scroll through:
   - the old way vs the ARISEVERSE way
   - validated market stats
   - the clickable **ARISE Method** explorer (A·R·I·S·E → 11 frameworks → 52 named tools)
   - the 5 phases
   - the ARIA X roleplay demo, which plays automatically
   - the six personas, the employer case, the founder, and the 7-business ecosystem
2. **Academy**: the curriculum explorer. Search "objection" or filter by pillar.
3. **ARIA X**: play the seller roleplay (3 choices). It ends with a scorecard and a link into the portal.
4. **Careers**: the six-pillar career wheel (click the segments) and the commission illustrator (AED/INR).
5. **For Employers**: the turnover-cost calculator and the Traditional vs ARISEVERSE table.
6. **Research**: the Market Health Diagnostic. Try the three scenarios and watch the gauge.
7. **Apply for Cohort 1**: About you → 6-question Ascent assessment → Ascent Profile → Reserve → **Enter the learning portal**.
8. **Portal**: Welcome screen (personalised from the application) → Dashboard → My Learning → Module 1 *The Mirror Method* (interactive Life Wheel) → ARIA X hub → Market Intelligence → Career & Placement.
   - To show the portal without applying first, open `portal.html#login` and click **Enter as demo learner**.
   - Settings → *Reset demo* clears the stored applicant.

## Content decisions to confirm with the client

| # | Topic | What the documents say | What the prototype does |
|---|---|---|---|
| 1 | Number of phases | June note: 4 phases. July master document: 5 phases | Uses the **5-phase** model (latest) |
| 2 | Dubai broker count | June note: ~32,000 (2025). July document: 23,536 (Q4 2024, marked Validated) | Uses **23,536** with source |
| 3 | Placement promise | IP deck: "Guaranteed Career Launch". Investor document: placement rate is a *Target* | Says "placement support with 30+ employer partners" and avoids "guarantee" |
| 4 | "Professional Excellence" | Name of Phase 2 *and* of category M42–46 | Kept both, which needs a rename to avoid confusion |
| 5 | Module levels | "52-module L1–L6 framework", but only L1 = Learn is defined | Shows "Level L1 · Learn" only |
| 6 | Real Estate Ecosystem doc | Labelled "Module 1" | Mapped to **M7 Real Estate Industry Overview** |
| 7 | Market Health Diagnostic | Labelled "Module 1: Market Intelligence Framework" | Used in **M16 Market Analysis & Trends** and as a free tool on the website |
| 8 | Duration, fees, dates, seats | Not specified (M1 deck mentions a 12-week tracking period). Cohort 1 targets are 60 India / 40 UAE | Shows "fees shared on counselling call". No dates or seat counts are shown |
| 9 | Partner employers | "30+ brokerage partnerships", unnamed | Generic descriptors only, with no real company names or logos |
| 10 | Module numbering | Client's dashboard mock-up shows "Module 19 — Off-Plan vs Ready". The ARISE Method deck has that module as M21; M19 is Residential Real Estate | Follows the deck: M19 = Residential Real Estate (75% in progress for the demo student) |
| 11 | Ascent Score | Shown on the client's dashboard mock-up ("68% Overall Ascent") with no formula | Portal shows a sample weighting (modules 40%, assignments 20%, attendance 15%, assessments 15%, practice 10%) to agree with the client |
| 12 | Targets vs facts | The investor document labels every claim Validated / Target / Assumption | The site keeps those labels on employer metrics, earnings, attrition and GDP outlooks |

## Photography and video (placeholders)

The prototype uses free stock media so it looks like a live site:
- 42 Unsplash photos.
- 13 Unsplash portraits, used as sample avatars in the portal.
- 8 Pexels videos, used as hero backgrounds, the portal sign-in panel and lesson players.

Sources and licences are listed in `media/CREDITS.md`. Both licences allow free commercial use without attribution. Points to make to the client:
- The people shown are models, not ARISEVERSE students, graduates or partners. The site labels the photography as illustrative, and the portal people as sample data.
- The founder is never shown with a stock photo; his monogram stays until a real photo is supplied.
- For launch, replace the stock media with a real shoot: a cohort group photo, a workshop in session, 1:1 coaching, a site visit, a certificate ceremony, the founder portrait, and short b-roll of a live class.

## Assets needed from the client

- Logo files and brand guidelines. The triangle "A" mark here is a placeholder based on the deck cover.
- Founder photo and full bio for Praveen P. Singh.
- Photography or video: classroom, cohort, Dubai and India.
- Office addresses, phone, email, and social handles.
- Fees, cohort dates, and the application or counselling process owner.
- Partner employer names and logos (with permission), plus any testimonials once Cohort 1 runs.

## Files

- `index.html`: public website (Home, Academy, ARIA X, Careers, For Employers, Research, About, Apply)
- `portal.html`: learning portal (login, welcome, dashboard, curriculum, lesson player, ARIA X hub, live classes, assignments, assessments, market intelligence, experts, careers, community, progress, settings)
- `assets/brand.css`: shared colours and type
- `assets/data.js`: the ARISE Method, 52 modules, phases, stats, and Market Health logic, shared by both
- `assets/site.*` and `assets/portal.*`: page-specific styles and behaviour
